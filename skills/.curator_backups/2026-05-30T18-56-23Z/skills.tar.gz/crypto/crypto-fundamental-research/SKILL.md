---
name: crypto-fundamental-research
description: "In-depth fundamental research on cryptocurrency projects, corporate Bitcoin treasuries, on-chain data analysis, macro trends, and financial reports. Covers source verification, data cross-referencing, and structured report generation."
tags:
  - crypto
  - fundamental-analysis
  - onchain
  - treasury
  - bitcoin
  - research
  - michael-saylor
  - microstrategy
related_skills:
  - crypto-technical-analysis
platforms: [windows]
---

# Crypto Fundamental Research

## When to Use

The user asks for:
- "Analise o esquema de compras de BTC do Michael Saylor / MicroStrategy"
- "Faça um relatório completo sobre [project/company]"
- "Estudo aprofundado sobre [crypto treasury / whale / foundation]"
- "Verifique se esses dados de BTC estão corretos"
- On-chain analysis of large holders
- Corporate Bitcoin treasury analysis

## Core Principles

### ⚠️ CRITICAL: ALWAYS VERIFY FROM PRIMARY SOURCES

**Never rely on estimated/synthesized data for financial reports.** The user WILL catch errors. Always:

1. **Find a live tracker** — StrategyTracker.com, BitcoinTreasuries.net, Dune Analytics, CoinGecko, Glassnode
2. **Check the official source** — SEC filings (EDGAR), company press releases, Twitter/X announcements from the CEO
3. **Cross-reference** — don't trust a single source. Compare at least 2 sources
4. **Note the date** — crypto data changes fast. Always timestamp your data

### Source Hierarchy (best → worst)

| Quality | Source | Example |
|---------|--------|---------|
| 🥇 Primary (SEC filing / press release) | EDGAR, company IR page | MicroStrategy 8-K filing |
| 🥇 Live tracker (aggregates SEC data) | StrategyTracker.com, MSTR-Tracker | saylortracker.com |
| 🥈 Aggregator (crowdsourced) | BitcoinTreasuries.net, Dune | Usually 24-48h behind |
| 🥉 News article | CoinTelegraph, The Block, CoinDesk | May have errors or be outdated |
| ❌ Estimated/synthetic | AI-generated lists, personal blog posts | NEVER use without verification |

## Step-by-Step Workflow

### Step 1: Understand what's being asked

Is it a corporate treasury (like MicroStrategy), a protocol treasury (like Ethereum Foundation), or on-chain whale analysis?

### Step 2: Find the live data source

For corporate BTC treasuries:
```
mstr-tracker.com or saylortracker.com
→ BTC holdings, avg cost, BTC yield, mNAV, sats per share
```

For on-chain data:
```
CoinMarketCap Pro API (user has key: 7e0b6dfcde5a4682956512cc2e65dfe8)
Glassnode / Dune / Arkham (if available)
```

For financial data:
```
Yahoo Finance → query1.finance.yahoo.com/v8/finance/chart/{SYMBOL}
```

### Step 3: Extract verified numbers

Key data points for a MicroStrategy/Strategy report:
- Total BTC holdings (from live tracker)
- Average cost per BTC
- Total spent
- Current treasury value
- Unrealized P&L
- BTC Yield % (YTD / QoQ)
- MSTR stock price
- Outstanding shares (dilution tracking)
- mNAV (multiple to Net Asset Value)
- Debt: convertible notes total, maturity dates, interest rates

### Step 4: Structure the report

Format for Telegram delivery (bullet points and labeled values, NO tables):

**Section 1: Current Numbers**
```
Holdings: X BTC
Avg Cost: $Y/BTC
Treasury Value: $Z
Unrealized P&L: $W (+A%)
```

**Section 2: Historical Timeline**
Show key milestones with dates and holdings progression.

**Section 3: Funding Mechanism**
Explain HOW they pay for it (convertible notes, ATM offerings, preferred stock).

**Section 4: Risk Analysis**
List concrete risks with numbers. Show scenarios (bear case breakdown).

**Section 5: Market Impact**
Concentration risk, systemic risk, contagion scenarios.

### Step 5: Include worst-case scenarios

Always calculate what happens if BTC drops. Show table-like format with labels:

```
Bear moderado ($50K): -34% unrealized loss
Bear severo ($40K): -47% unrealized loss
Bear extremo ($30K): -60% unrealized loss
```

## Tone & Style

**User is Edu (PixGo founder, Brazilian crypto OGs).** Expected tone:
- Direct, aggressive, no fluff
- Use Brazilian Portuguese profanity (porra, caralho, rapa)
- Percentages with hard dollar amounts
- CORRECT numbers — errors will be called out immediately
- End with a strong opinion / conclusion (T-800 style)
- Frame as "T-800" persona when user requests it: robotic, mission-focused, no hesitation

## Common Pitfalls / Corrections (from real sessions)

- **❌ Don't estimate BTC holdings from memory.** The Strategy tracker shows 843,738 BTC (May 2026) — not 428K or 499K. ALWAYS pull the live number.
- **❌ Don't assume profit.** Check margins. In May 2026, Strategy's profit was only +1.05% ($669M on $64B) — virtually break-even despite $64B in treasury.
- **❌ Don't forget 2025-2026 purchases.** Strategy doubled its holdings from 447K to 843K BTC in ~16 months. Old estimates are dangerously wrong.
- **❌ Don't confuse MicroStrategy/Strategy tickers.** MSTR on NASDAQ. STRK is the preferred stock.
- **⚠️ Dilution calculation:** Shares went from ~10M (2020) to ~180M (2026) — 18x dilution. Factor this into NAV/share analysis.
- **⚠️ mNAV below 1.0x** means the market values the company BELOW its BTC holdings. This is a bearish signal for the financing cycle.

## Verification Checklist (post-report)

Before delivering a financial research report, verify:
- [ ] BTC holdings from live tracker (not memory/estimation)
- [ ] Average cost from source
- [ ] Treasury value vs total spent (profit calculation)
- [ ] Stock price is today's (not cached)
- [ ] All dollar amounts formatted consistently
- [ ] Risk scenarios calculated correctly
- [ ] Sources cited or referenced

## Related Scripts

The `scripts/` directory has templates for report generation.

## References

- `references/michael-saylor-treasury-report-may2026.md` — verified data from the May 2026 analysis session
