---
name: crypto-technical-analysis
description: "Real-time technical analysis of cryptocurrency charts (BTC, ETH, altcoins) using Binance API. Generates structured market overviews with support/resistance, indicators, and trade scenarios."
tags:
  - crypto
  - technical-analysis
  - bitcoin
  - ethereum
  - trading
  - binance
  - indicators
related_skills: []
platforms: [windows]
---

# Crypto Technical Analysis — Multi-Timeframe

## When to Use

The user asks for:
- "Analyze BTC/ETH on the 4h chart"
- "What's the market looking like?"
- Technical indicators for a specific crypto
- Support/resistance levels
- "Should I buy or sell?"

## Core Workflow

### Step 1: Fetch data from Binance

Use the public Binance API (no key needed for klines):

```python
import requests

# Timeframes: 1m, 5m, 15m, 30m, 1h, 4h, 1d, 1w
symbol = "BTCUSDT"  # or ETHUSDT, SOLUSDT, etc.
interval = "4h"
limit = 150  # enough for SMA50, MACD, Bollinger

url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}"
data = requests.get(url).json()
```

### Step 2: Calculate indicators

Extract from the response (each candle: [open, high, low, close, volume, ...]):

```python
closes = [float(c[4]) for c in data]
highs = [float(c[2]) for c in data]
lows = [float(c[3]) for c in data]
volumes = [float(c[5]) for c in data]
current = closes[-1]

# Simple Moving Averages
sma_20 = sum(closes[-20:]) / 20
sma_50 = sum(closes[-50:]) / 50

# EMA
def ema(values, period):
    multiplier = 2/(period+1)
    result = [sum(values[:period])/period]
    for price in values[period:]:
        result.append((price - result[-1])*multiplier + result[-1])
    return result

ema12 = ema(closes, 12)[-1]
ema26 = ema(closes, 26)[-1]
macd = ema12 - ema26

# RSI (14 periods)
gains = [closes[i]-closes[i-1] for i in range(1, len(closes))]
avg_gain = sum(max(0,g) for g in gains[-14:])/14
avg_loss = sum(abs(min(0,g)) for g in gains[-14:])/14
rsi = 100 - 100/(1+avg_gain/avg_loss) if avg_loss != 0 else 100

# Bollinger Bands (20, 2)
sma20 = sum(closes[-20:])/20
variance = sum((c-sma20)**2 for c in closes[-20:])/20
std = variance**0.5
bb_up = sma20 + 2*std
bb_dn = sma20 - 2*std
```

### Step 3: Find support/resistance pivots

Simple pivot-detection (NOT exhaustive, but fast):

```python
pivots = []
for i in range(2, len(highs)-2):
    if highs[i] > highs[i-1] and highs[i] > highs[i-2] and \
       highs[i] > highs[i+1] and highs[i] > highs[i+2]:
        pivots.append(('RES', highs[i]))
    if lows[i] < lows[i-1] and lows[i] < lows[i-2] and \
       lows[i] < lows[i+1] and lows[i] < lows[i+2]:
        pivots.append(('SUP', lows[i]))
```

### Step 4: Structure the output

Present to the user in a clear, Telegram-friendly format (no tables):

**Price**: $XX,XXX
**Timeframe**: 4H

**Medium-term trend**: BAIXA (SMA20 < SMA50) or ALTA
**MACD**: Bullish/Bearish (histogram value)
**RSI**: XX (Neutral / Oversold / Overbought)
**Bollinger**: Inside / Touching upper / Touching lower band

**Suportes:**
- $XX,XXX
- $XX,XXX

**Resistências:**
- $XX,XXX
- $XX,XXX

**Cenários:**
- 🟢 Alta (XX%): [conditions for reversal]
- 🔴 Baixa (XX%): [conditions for continuation]

### Step 5: Add candlestick context

Show the last 6-10 candles to tell a story. Look for:
- Rejection wicks (long lower shadows after a drop)
- Volume spikes (above average = conviction)
- Doji (indecision)
- Engulfing patterns

## Tone & Style

**User is Edu (PixGo founder, Brazilian crypto OG).** Expected tone:
- Direct, no fluff
- Use Brazilian crypto slang ("raaapaa", "porra", "sangrando")
- Percentages and hard numbers, not hand-wavy "might go up"
- Give a clear directional bias with confidence level (%)
- End with a "pro seu trade" summary — actionable, not academic

## Pitfalls

- **Binance rate limits** — 1200 requests/minute for public endpoints. Fine for single-symbol analysis.
- **USDT pairs only** — Binance API uses USDT by default. If user mentions BRL pairs, adjust to BTCBRL or ETHBRL.
- **Windows/python3** — use `python` not `python3`. Verify with `python --version` first.
- **4H timeframe limitation** — pivots found are for the 4h chart only. Don't extrapolate to daily/weekly levels without fetching higher timeframe data.
- **No order book / CVD / bid-ask spread** — pure OHLCV analysis. Don't claim to detect "whale manipulation" or "spoofing" without order book data.
- **Self-reported analysis, not investment advice** — frame as "if I were trading", not "this will happen".
- **Windows/python3** — on git-bash/MSYS, `python3` may point to the Microsoft Store installer shim and fail with exit code 49. Always use `python` (not `python3`) for scripts.
- **File paths in curl/wget** — on Windows bash, curl to `C:\Users\PC\` needs either POSIX-style `/c/Users/PC/` or escape the colon. Prefer storing temp files with `curl -s URL > /tmp/filename` which works on git-bash.

## Related Scripts

The `scripts/` directory has reusable analysis templates. Copy and modify for each session.

## References

- Binance API docs: https://binance-docs.github.io/apidocs/spot/en/#kline-candlestick-data
- RSI formula: Wilder's smoothed RSI (14)
- Bollinger Bands: 20 SMA ± 2 standard deviations
