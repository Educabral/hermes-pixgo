# Skeptic Editor Principles

What the Skeptic Editor destroys in every draft — use as a checklist before publishing.

## Common Mistakes (from real session)

### 1. Opening with a generic rhetorical question
BAD: "Você confia na sua stablecoin?"
WHY: Qualquer leitor cripto cansou dessa pergunta há 5 anos. Não provoca choque — provoca tédio.
FIX: Abra com o FATO. "Privkey vazou. 2.8M mintados."

### 2. Numbers without context
BAD: "US$ 2.8 milhões em EURS e USDS desabaram de paridade."
WHY: $2.8M é mixaria perto do mercado de $307B. Parece assustador só se o leitor não sabe o tamanho do mercado. Leitor informado pensa "só isso?" e perde confiança no autor.
FIX: Contextualize — % do supply afetado, % do market cap, ou admita que o valor absoluto é pequeno mas o significado é grande.

### 3. Triple parallel structure
BAD: "Não foi bug. Não foi ataque de smart contract. Foi erro humano."
WHY: Estrutura manjada de copywriting de coach quântico.
FIX: Corte direto. "Privkey vazou. Ponto."

### 4. Generic generalization
BAD: "Isso é o problema de TODA stablecoin centralizada."
WHY: Mentira intelectual. Circle tem HSM, custódia qualificada, seguro, segregação de chaves. StablR tratava opsec como depois do expediente.
FIX: "O erro não é ser centralizado — é ser negligente."

### 5. "Auto-custódia resolve tudo" as mantra
BAD: "Auto-custódia não é luxo. É o mínimo."
WHY: Auto-custódia introduz dezenas de outros riscos (phishing, seed perdida, ransomware, erro de rede). Troca um conjunto de riscos por outro.
FIX: Seja honesto — auto-custódia resolve custódia, mas não resolve segurança do usuário.

### 6. Generic ending that fits any topic
BAD: "Ou você aprende com o erro dos outros, ou vai ser a próxima vítima."
WHY: Serve pra golpe do Pix, dieta, investimento em franquia. Zero personalidade.
FIX: Final específico, com deboche ou murro. "Se não sabe quem segura a chave, não tá investindo — tá torcendo."

## What every post must have
- Data do evento
- Ticker exato
- Mecanismo do exploit (COMO a privkey vazou? Phishing? Funcionário? Repo público?)
- Threshold da multisig (2/3 ou 3/3?)
- Chain onde ocorreu
- Reação do emitente (pausaram mint? indenizaram?)
- Comparação com similares se relevante
