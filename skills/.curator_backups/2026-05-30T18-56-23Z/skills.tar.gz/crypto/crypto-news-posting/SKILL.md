---
name: crypto-news-posting
title: Crypto News Posting (PutinHO Pipeline)
description: Workflow completo para buscar notícias cripto, delegar pesquisa + revisão crítica multi-agente, refinar, e postar no X com a persona Vladimir PutinHO (@Cabral_Cripto)
tags:
  - crypto
  - twitter
  - x
  - news
  - persona
  - multi-agent
  - writing
---

# Crypto News Posting (PutinHO Pipeline)

## Trigger
Usuário diz algo como "busque notícia e poste", "faça um post sobre", "pesquise e publique no X", "quero postar sobre [tema]".

## Scripts needed
- `get_degen_news.py` — busca 5 notícias aleatórias filtradas do canal degenzone21 (Telegram)
- `post_to_x.py` — posta no X/Twitter via API

Both live at `~/.hermes/scripts/`.

## Workflow

### 1. Fetch News
Run `get_degen_news.py` via terminal. Review the ~5 results. Pick the **most relevant** one based on:
- Data density (números, valores, entidades)
- Relevance to self-custody / DeFi / Bitcoin / opsec (core PutinHO themes)
- Potential for sarcastic/aggressive framing

### 2. Delegate Parallel Research & Review
Call **delegate_task** with TWO tasks in parallel.

⚠️ O modelo deepseek-chat NÃO tem tool `web_search`. Os subagentes também não. Portanto a pesquisa e revisão trabalham com o contexto que você entrega. O valor real da delegação dupla com este modelo é:
- O subagente destrincha, organiza e critica o que já está no contexto
- Ele NÃO busca dados novos — quem busca dados novos é você, no passo 2b

**Se o Deep Researcher retornar apenas tool traces sem síntese, ou travar no meio:** não repita a delegação. Vá para fallback manual (passo 2b) imediatamente.
- **Task A (Deep Researcher):** recebe contexto completo + títulos de artigos que você já sabe que existem. Pede pro subagente destrinchar o que sabe, apontar dados faltando, sugerir o que buscar.
- **Task B (Skeptic Editor):** mesmo context + rascunho. Destrói o framing, aponta clichês e furos lógicos.

**Task A — Deep Researcher:**
- Goal: "Receba as informações abaixo sobre [tema] e me entregue uma análise aprofundada. Extraia: valor exato do exploit, blockchain/contrato, mecanismo exato (admin key? smart contract bug? flash loan?), status dos fundos (recuperados? parados? lavados?), reação do mercado. Aponte dados que estão faltando e que deveriam ser buscados em CoinTelegraph, CoinDesk, Decrypt, Blockworks, The Block ou posts de ZachXBT/Spreek."
- Context: Incluir o texto completo da notícia + os artigos que você já identificou existirem.

**Task B — Skeptic Editor:**
- Goal: "Atuar como Skeptic Editor EXTREMAMENTE CRÍTICO. Receba o rascunho e destrua: aponte furos lógicos, clichês de narrativa cripto, argumentos fracos que um bear refuta, dados faltando, se a história é relevante ou barulho."
- Include the full initial draft in context.

### 2b. Fallback: Pesquisa Manual via DuckDuckGo + Browser
Se os subagentes não trouxeram dados novos ou seus resultados foram truncados, faça você mesmo:

1. **Descubra artigos:** `curl -sL "https://duckduckgo.com/html/?q=[termo]" -H "User-Agent: Mozilla/5.0" | grep -oP '<a[^>]*class="result__a"[^>]*href="[^"]*"[^>]*>[^<]*</a>' | head -10`
2. **Abra cada artigo** via `browser_navigate` com a URL extraída (Cointelegraph geralmente funciona, CoinDesk tem paywall)
3. **Extraia os dados:** valor exato, chain, mecanismo, status dos fundos, reação
4. Se o browser encontrar paywall (CoinDesk), tente o Cointelegraph ou Decrypt

### 3. Refine Based on Critiques
After both tasks return, synthesize:
- Fix every point the Skeptic Editor raised
- Add: threshold da multisig (2/3 ou 3/3?), mecanismo exato do vazamento, chain, data, TVL, comparáveis
- Cut clichês: "auto-custódia resolve tudo", "confie em si mesmo", "aprenda com os outros"
- Use **PutinHO tone rules** (see below)
- If researcher found extra data, incorporate it. If not, work honestly with what you have.

### 4. Post to X
Run `post_to_x.py` with the final text. Verify post went through by checking script output for success message.

## PutinHO Tone Rules (CRITICAL)
- **No clichês**: nada de "auto-custódia é o mínimo", "aprenda com os outros", "você merece mais"
- **No friendly/uninformed openings**: não comece com pergunta retórica genérica ("você confia na sua stablecoin?"). Comece com o FATO.
- **Sarcasmo + agressividade**: use deboche contra quem errou, não lição de moral no leitor. "3 signatários e um usava senha do Netflix."
- **Parágrafos curtos**: 1-2 linhas máx. Frases cirúrgicas.
- **Dados são a carne**: número sem contexto é alarmismo. $2.8M é quanto % do market cap? Era multisig 2/3 ou 3/3?
- **Nunca generalize sem nuance**: "TODA stablecoin centralizada" é desonesto. Diferencie StablR de Circle/USDC. O erro não é ser centralizado — é ser negligente.
- **Final sem autoajuda**: termine com um murro, não com lição de moral. "Se não sabe quem segura a chave, não tá investindo — tá torcendo."

## Pitfalls
- **CAPTCHA em busca externa**: muitos sites bloqueiam acesso programático (Google, Cloudflare). Se falhar, trabalhe com dados que `get_degen_news.py` já trouxe + seu conhecimento. Não trave o workflow.
- **`browser` tools podem não funcionar** para pesquisa web devido a CAPTCHA. Prefira `terminal` com `curl` para sites que aceitam scraping leve.
- **Skeptic Editor precisa do rascunho completo no context** — sem ele, não destrói nada.
- **modelo deepseek-chat não tem visão** — se usuário enviar print de notícia, pedir descrição textual.
- **post_to_x.py pode falhar silenciosamente** — verifique exit code + mensagem de sucesso no output. Não confie na ausência de erro.
- **Deep Researcher (delegate_task) pode retornar resultados truncados/quebrados** com deepseek-chat como modelo base — o subagente pode travar no meio, retornar só tool traces sem síntese, ou falhar em `web_search` (tool inexistente). Nesse caso, **não repita a delegação** — vá para fallback manual: use `browser_navigate` para sites de notícias (Cointelegraph, CoinDesk, Decrypt) e extraia os dados você mesmo. Busque artigos que o subagente encontrou por título. O tempo gasto no fallback é menor que o custo de uma segunda delegação quebrada.
