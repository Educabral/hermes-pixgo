---
name: pixgo-med-email
title: Resposta a MEDs (Mecanismo Especial de Devolução) — PixGo
description: Workflow e templates para responder contestações MED do Banco Central/DEPIX na plataforma PixGo. Cobre defesa contra estorno, comunicação de cancelamento, e prazos regulatórios.
tags:
  - pixgo
  - med
  - depix
  - banco-central
  - email
  - suporte
  - contestação
  - estorno
---

# Resposta a MEDs (Mecanismo Especial de Devolução) — PixGo

## Trigger

Usuário diz algo como "responde esse email", "responda a contestação", "elabore a resposta do MED", "faz o retorno do MED", "responda pro suporte", ou passa um print/texto de uma contestação MED.

## Contexto

MED é um recurso do Banco Central que permite ao pagador contestar uma transação PIX. A PixGo é interface tecnológica — quem decide é a DEPIX em conjunto com o BC. O prazo de análise é **15 a 20 dias corridos**, podendo variar.

## Regras OBRIGATÓRIAS em toda resposta

1. **Prazo de análise:** SEMPRE mencionar que o prazo médio é de 15 a 20 dias corridos, podendo variar conforme fila e complexidade.
2. **Imparcialidade:** Deixar claro que a decisão final cabe à DEPIX + Banco Central, e que a PixGo atua como interface tecnológica, não retendo nem liberando valores.
3. **Variação OBRIGATÓRIA:** Cada resposta deve ter estrutura e vocabulário DIFERENTES das anteriores. O usuário PEDE isso explicitamente. Variar abertura ("Olá, tudo bem?" / "Prezado(a), boa tarde." / "Prezado(a), boa noite."), organização dos parágrafos (contexto do MED antes da defesa / fatos primeiro / abertura com agradecimento), e escolha de palavras. Usar um repertório diverso de sinônimos (contestação/MED/recurso, análise/avaliação/apreciação, comprovação/evidência/registro).
4. **Tom profissional:** Corporativo, neutro, sem emoção. A defesa é baseada em FATOS — pagamento voluntário, atendimento iniciado, serviço executado.
5. **Oferecer envio de docs:** Sempre encerrar oferecendo que o usuário pode enviar prints/comprovantes adicionais para anexar ao processo.

## Template estrutural (NUNCA usar o mesmo texto, só como guia de tópicos)

### Abertura
- Agradecer/confirmar recebimento dos dados
- Informar que foi registrado para análise

### Corpo da defesa (adaptar conforme o caso)
- Pagamento foi voluntário e aprovado normalmente
- Atendimento iniciado após confirmação (via WhatsApp)
- Serviço começou a ser executado sem interrupção/negação
- Cliente abriu MED mesmo com serviço em andamento
- Concluir que não há fundamento para estorno

### Prazo e papel das instituições
- MED é regulado pelo BC, criado para coação/golpe/fraude, não cancelamento
- Pedido de rejeição protocolado
- Prazo de 15 a 20 dias corridos
- Decisão final: DEPIX + BC. PixGo é interface, não retém/libera valores

### Encerramento
- Oferecer envio de documentos complementares
- Disponibilidade para dúvidas

## Variações de vocabulário

| Conceito | Alternativa 1 | Alternativa 2 | Alternativa 3 |
|----------|--------------|---------------|---------------|
| MED | contestação | recurso | Mecanismo Especial de Devolução |
| análise | avaliação | apreciação | verificação |
| comprovante | evidência | registro | documentação |
| prazo | período | tempo estimado | janela |
| cliente | pagador | usuário | contratante |
| estorno | devolução | reversão | cancelamento da transação |

## Casos especiais

### Cliente cancelou o MED e fez estorno por conta própria
Mesmo com cancelamento, o processo PRECISA passar pela análise formal da DEPIX/BC para dar baixa no registro e garantir conformidade. Explicar:
- O MED precisa ser validado oficialmente pelas instituições
- A análise segue o fluxo mesmo com desistência
- Relembrar prazo de 15-20 dias
- Orientar manter comprovante do estorno particular como evidência

### Estorno no mesmo dia (transação ainda em trânsito)
Explicar que a PixGo só consegue reverter enquanto o valor está em trânsito. Se já foi liquidado para a carteira do recebedor, não é possível reverter por intermédio da plataforma.

## Pitfalls
- **Nunca copiar a mesma resposta duas vezes:** o usuário pediu explicitamente variação. Mudar abertura, ordem dos argumentos, e vocabulário.
- **Não omitir o prazo:** é a reclamação mais frequente — SEMPRE mencionar 15-20 dias.
- **Não se colocar como autoridade de decisão:** deixar claro que PixGo é interface, quem decide é DEPIX/BC.
- **Não julgar o comportamento do cliente:** manter neutralidade. O relato é factual, não emocional.
- **Não prometer resultado:** dizer "pedido de rejeição foi registrado para análise", nunca "vai ser rejeitado".
- **Sempre manter parágrafos: corpo do email bem organizado**, sem bloco de texto contínuo.
- **Plain text**: emails de suporte PixGo são em texto plano, sem formatação HTML/rich text.
