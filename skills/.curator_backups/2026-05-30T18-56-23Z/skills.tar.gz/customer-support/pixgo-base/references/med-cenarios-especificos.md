# Cenários Específicos de MED — Casos Reais

Coletados do atendimento real do Edu, Gerente de Conta PixGo.
Cada caso é de um lojista diferente.

## 1. Cliente usa o produto (recarga/assinatura) e depois abre MED

**Contexto:** Cliente recebeu código de recarga, ativou e usou, mas abriu MED. Loja tentou contato e o cliente não responde.

**Resposta:** Confirmar recebimento, registrar que o produto foi entregue e ativado pelo cliente. Mencionar que a tentativa de contato sem retorno foi anotada. Seguir com prazo normal de 15-20 dias. Oferecer opcionalmente envio de prints/logs de ativação.

**NÃO fazer:** Dizer que cliente agiu de má fé ou fazer juízo de valor. Manter neutralidade factual.

## 2. Loja admite erro do sistema e solicita reembolso

**Contexto:** Lojista confirma que o cliente não recebeu o produto por erro interno (bug, falha de sistema) e pede estorno integral.

**Resposta:** Agradecer pela honestidade. Explicar que o estorno só é possível no mesmo dia (valor em trânsito). Se já passou de D+1, o valor já foi liquidado para a wallet do lojista e a PixGo não consegue reverter — o DEPIX está sob custódia do vendedor. Registrar a solicitação de estorno e verificar o status da transação.

**Importante:** Diferenciar de MED. O lojista está PEDINDO estorno, não respondendo a uma contestação. Se for MED, seguir o fluxo de mediação com prazo de 15-20 dias.

## 3. Cliente satisfeito que nega ter pedido estorno

**Contexto:** Cliente afirma que está satisfeito com o produto e não pediu estorno. Loja não entende por que o MED foi aberto.

**Resposta:** Registrar a declaração do cliente. O MED pode parecer contraditório nessa situação. Ficar nos fatos que o lojista apresentou (cliente satisfeito, não solicitou estorno). Seguir prazo normal. **NÃO especular** que o banco abriu o MED sem o cliente saber — isso não existe e o usuário corrige.

## 4. Loja tentou contato sem sucesso e pede devolução para o cliente

**Contexto:** Lojista tentou falar com o cliente sobre o MED/estorno, não obteve resposta, e pede à PixGo que realize a devolução do valor.

**Resposta:** Registrar a solicitação e a tentativa de contato. Encaminhar para análise do mediador dentro do prazo normal de 15-20 dias. Se o valor ainda estiver em trânsito (mesmo dia), verificar possibilidade de estorno. Caso contrário, o MED segue o fluxo normal.

## 5. Cliente apressa o vendedor e abre MED mesmo após receber

**Contexto:** Cliente pagou, apressou o vendedor para enviar o acesso, o vendedor enviou horas depois, e o cliente abriu MED mesmo tendo recebido.

**Resposta:** Registrar que o acesso foi enviado e o cliente estava ciente. Os prints comprovam a entrega. Seguir prazo normal de análise.

## 6. Venda de serviço (edição, freela) com cliente negando estorno

**Contexto:** Serviço prestado (edição, consultoria, etc.), cliente alega que não pediu estorno.

**Resposta:** Registrar que o cliente nega ter solicitado o estorno. Esse é um ponto favorável à defesa. Manter prazo normal. Oferecer envio de prints da conversa.
