# Banco de Vocabulário — Respostas MED PixGo

Use este banco para variar palavras ao responder múltiplos casos em sequência.
Evite repetir a mesma combinação em respostas consecutivas.

## Verbos para "recebemos o documento"

- recebemos o comprovante / print / documento / material
- o documento foi anexado / inserido / adicionado / incorporado / registrado
- o material foi incluído / direcionado / remetido / transmitido / encaminhado
- o conteúdo foi inserido / registrado / incorporado ao processo
- o print que você disponibilizou / enviou / anexou / encaminhou / nos enviou

## Verbos para "será analisado"

- será encaminhado para análise do mediador
- será direcionado para apreciação do mediador
- será remetido ao mediador encarregado
- será transmitido ao mediador responsável
- será submetido à avaliação do mediador designado
- será considerado pela equipe de mediação
- seguirá para análise do mediador

## Frases sobre "o material ajuda na defesa"

- Esse tipo de comprovante é importante para demonstrar que a entrega foi realizada
- Registros que atestam a conclusão da entrega são levados em conta na avaliação
- Esse material contribui para fundamentar sua defesa junto ao mediador
- Evidências visuais ou documentais agregam valor à sua posição no processo
- Ter provas que comprovem o uso do serviço fortalece sua argumentação
- Documentos demonstrando a efetivação do serviço servem como subsídio para a decisão

## Variações para prazo de 15-20 dias

- O prazo médio para conclusão é de 15 a 20 dias corridos
- O prazo estimado para retorno gira em torno de 15 a 20 dias corridos
- A devolutiva costuma ocorrer em aproximadamente 15 a 20 dias corridos
- O prazo previsto para resposta fica entre 15 e 20 dias corridos
- A análise tem um prazo médio de 15 a 20 dias corridos
- O período de avaliação é de cerca de 15 a 20 dias corridos

## Variações para "pode variar"

- podendo sofrer alterações conforme o volume da fila
- podendo variar conforme a demanda do momento
- podendo oscilar dependendo da complexidade do caso
- podendo se estender ou reduzir conforme a rotatividade de solicitações
- sujeito a ajustes dependendo do fluxo de processos em andamento

## Variações para "acompanhe pelo painel"

- Você pode acompanhar o andamento pelo seu painel
- O status pode ser consultado diretamente pelo seu painel
- Você consegue verificar o progresso pelo painel de controle
- Acompanhe a evolução pelo seu dashboard
- O trâmite pode ser monitorado pelo seu painel a qualquer momento
- Você pode checar o status atualizado pelo painel

## Variações para "se tiver mais documentos"

- Se houver outros materiais que possam reforçar sua defesa, fique à vontade para enviar
- Caso possua outras evidências complementares, pode nos encaminhar
- Se surgirem outros documentos que possam contribuir, sinta-se livre para compartilhar
- Se tiver outros elementos que possam apoiar sua argumentação, pode nos enviar
- Caso haja provas adicionais que fortaleçam seu posicionamento, disponibilize para nós
