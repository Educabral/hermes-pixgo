---
name: pixgo-base
description: "Base de conhecimento completa da PixGO — API, regras de MED, parceiros bancários, limites, webhooks, e scripts de resposta para atendimento ao cliente."
version: 1.1.0
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [pixgo, atendimento, med, api, suporte]
    related_skills: []
---

# PixGO — Base de Conhecimento para Atendimento

## Parceiros Bancários (ATUALIZADO)
- **Processamento PIX:** Xend e Transfero (NÃO é mais PLEBANK/Fitbank)
- **Tecnologia de Conversão DEPIX:** Depix.info
- **Empresa:** PixGo.org — sediada em Casper, Wyoming, EUA

## Regras Importantes de Atendimento

### MED (Mecanismo Especial de Devolução)
- Ocorre quando o cliente contesta a compra no banco (até 80 dias após o PIX)
- Status muda para `MED` (ainda não é `refunded`)
- Vendedor tem **5 dias** para enviar comprovações
- Se não responder, perde por W.O.
- Se o banco aprovar a defesa, status volta para `completed`
- **MED cancelado pelo cliente:** mesmo assim o processo de verificação interna segue — é um sistema de proteção ao usuário e precisa ser investigado pelas instituições (Xend e Transfero, seguindo diretrizes do BC)
- **MED ainda não analisado + lojista autoriza devolução:** registrar a manifestação de concordância e anexar ao processo. O MED segue o fluxo normal de análise (15-20 dias), a autorização agiliza mas não pula a fila
- **Sempre informar prazo de 15 a 20 dias corridos** em toda resposta sobre MED

### "Devolução" — Cuidado com Ambiguidade
- Quando o lojista diz "pode reembolsar" ou "pode estornar" no contexto de MED, ele está **autorizando a devolução** dentro do processo de mediação — NÃO está pedindo um estorno ativo da PixGo
- Não confundir com estorno voluntário do mesmo dia
- Resposta correta: registrar a autorização, informar que o MED segue o fluxo normal de análise (15-20 dias), e explicar que a concordância agiliza mas a decisão é do mediador

### Quem Decide o MED
- A análise é feita pela **Depix** em conjunto com os critérios do Banco Central
- A **PixGo NÃO** faz retenção de valores — atua como interface tecnológica
- A palavra final sobre a adequação da transação cabe às **instituições reguladas** que processam o pagamento

### REGRA CRÍTICA — NÃO PEDIR COMPROVANTES AO LOJISTA
- **NUNCA** peça comprovante de envio, nota fiscal, rastreio, print de conversa ou qualquer evidência para o lojista
- A PixGo é **imparcial** e não se mete na relação comercial entre vendedor e comprador
- Quem pede evidências é o mediador (Depix + banco), não a PixGo
- Se o lojista enviar documentos voluntariamente, registre que foram anexados ao processo
- Mas **não solicite ativamente** — isso passa a impressão errada de que a PixGo julga o mérito
- Exceção: só pergunte o status do pagamento no painel ("pending" ou "completed") para saber se ainda está no prazo de estorno do mesmo dia
- Se o lojista já enviou o print, responder confirmando recebimento e que seguirá para análise. **Oferecer opcionalmente** que o lojista pode enviar documentos complementares (ele já iniciou o envio, então não é uma solicitação ativa — é um desdobramento natural da conduta do próprio lojista)

### Estorno e Devolução
- Só é possível estornar enquanto o valor está **em trânsito** (mesmo dia)
- **Mesmo dia do pagamento:** cliente deve solicitar à PixGo pelo Telegram — é possível estornar enquanto o valor não foi liquidado
- **Dia seguinte (D+1):** valor já foi liquidado e enviado para a wallet Liquid do vendedor — **impossível reverter**, o DEPIX já está sob posse exclusiva do vendedor
- Se já foi liquidado para a wallet Liquid, **não é mais possível reverter**

## Alerta de Alto Índice de MEDs — Bloqueio de Conta

Quando Edu pedir para enviar e-mails de advertência a lojistas com alto número de MEDs:

1. **Usar template `med-alerta-alto-indice.md`** como base
2. **Variar a estrutura** entre os destinatários (não enviar o mesmo texto para todos)
3. **Tom:** profissional e firme, mas não agressivo
4. **Elementos obrigatorios:**
   - Motivo: numero elevado de MEDs identificado
   - Consequencia: bloqueio temporario ou encerramento se nao reduzir
   - Prazo: "nos proximos dias" (generico)
   - Sugestao: revisar processos de entrega e atendimento
   - Manter registros comprobatorios das transacoes
5. **Para cada destinatario, criar um e-mail individual** com variacao de estrutura e vocabulario

### Desativação Automática de Webhooks
- Mais de 50 falhas consecutivas (Timeout, Erro 500, servidor offline) → webhook desativado automaticamente
- Reativação: usuário deve logar no painel > Desenvolvedores / API > corrigir URL > salvar manualmente
- Suporte não faz essa alteração por segurança

## Níveis e Limites
7 níveis progressivos baseados em histórico de transações confirmadas:
1. **Iniciante** (0 a R$ 299.99): Limite R$ 300 / QR
2. **Bronze** (R$ 300 a R$ 499.99): Limite R$ 500 / QR
3. **Prata** (R$ 500 a R$ 999.99): Limite R$ 1.000 / QR
4. **Ouro** (R$ 1.000 a R$ 2.999.99): Limite R$ 1.500 / QR
5. **Platina** (R$ 3.000 a R$ 4.999.99): Limite R$ 2.000 / QR
6. **Diamante** (R$ 5.000 a R$ 5.999.99): Limite R$ 2.500 / QR
7. **Elite** (R$ 6.000+): Limite R$ 3.000 / QR

### Regras Fixas
- Mínimo R$ 10,00 por transação
- Máximo R$ 3.000 por QR Code (regra BC)
- Limite diário por CPF/CNPJ pagador: R$ 6.000
- QR Codes ilimitados por dia
- Vendas maiores que R$ 3.000: fatiar em múltiplos QRs

## Taxas
- Valores **acima de R$ 50,00**: 2% sobre o valor
- Valores **de R$ 10,00 a R$ 50,00**: 2% + R$ 1,00 fixo
- Liquidação D+1: Taxa Liquid de **R$ 0,50** por envio
- Zero mensalidade, zero taxa de adesão

## Webhooks
### Headers
- `X-Webhook-Event`: Ex. payment.completed
- `X-Webhook-Timestamp`: Timestamp Unix
- `X-Webhook-Signature`: Hash HMAC-SHA256

### Validação HMAC
1. Concatene timestamp + "." + raw JSON payload
2. Gere HMAC-SHA256 com a Webhook Secret
3. Compare com X-Webhook-Signature (timing-safe)
4. Opcional: rejeitar timestamps mais antigos que 300s

### Eventos
- `payment.completed`
- `payment.expired`
- `payment.refunded`

## Status de Pagamento
- `pending` — Aguardando pagamento
- `completed` — Pagamento confirmado
- `expired` — QR Code expirou (20 min avulso, 30 min cobrança)
- `cancelled` — Pagamento cancelado
- `MED` — Cliente abriu contestação
- `refunded` — Estorno finalizado

## Arquivos de Apoio

- **`references/med-vocabulary-bank.md`** — Banco de variações de palavras e frases para evitar repetição ao responder múltiplos casos em sequência (Edu rejeita respostas com estrutura idêntica no mesmo bloco)
- **`references/med-cenarios-especificos.md`** — Casos reais de MED encontrados no atendimento: cliente que usou e contestou, loja que admitiu erro, cliente satisfeito que nega estorno, venda de serviço com cliente negando pedido, etc.
- **`templates/med-print-recebido.md`** — 3 estruturas diferentes de resposta para quando o lojista envia print de comprovante no MED
- **`templates/med-alerta-alto-indice.md`** — 3 estruturas de e-mail de advertência para lojistas com alto índice de MEDs, ameaçando bloqueio/encerramento da conta

## Script de Resposta para MED (Tom Gerente de Conta)

### Estrutura Obrigatória
1. **Agradecer o contato** e confirmar recebimento dos documentos
2. **Esclarecer o papel da PixGo** (interface tecnológica, não é a mediadora)
3. **Explicar quem analisa** (Depix + BC, através das instituições Xend/Transfero)
4. **Orientar sobre prazos** (15-20 dias corridos para análise) — **sempre** incluir o prazo
5. **Oferecer suporte** contínuo

### Regras de Redação
- Tom **extremamente profissional e corporativo**
- **PROIBIDO** usar emojis
- **PROIBIDO** usar markdown (asteriscos, hashtags, negritos) — texto plain
- **NUNCA** copiar template igual — variar palavras e estrutura a cada resposta
- **REGRRA CRÍTICA: quando o Edu enviar múltiplos casos de MED em sequência, cada resposta DEVE usar palavras, estrutura de frases, e ordem de informações DIFERENTES da anterior.** Não basta trocar o número do pedido — é preciso reescrever com vocabulário novo (ex: "recebemos o comprovante" → "o documento enviado foi anexado" → "seu material foi registrado" → "o print que você disponibilizou"). Variar verbos (receber, anexar, registrar, incluir, direcionar, adicionar, incorporar), variar a ordem dos parágrafos, e variar os termos de prazo (cerca de, aproximadamente, estimado em, gira em torno de, previsto para). Edu rejeita respostas com estrutura idêntica quando enviadas no mesmo bloco.
- Ser **estritamente imparcial** — PixGo não julga, apenas informa
- Incluir sempre: prazos, nome da Depix, referência ao BC, parceiros Xend/Transfero

### Pitfalls — Erros Comuns ao Responder
- **Cada email é de um USUÁRIO DIFERENTE** — não assumir continuidade de conversa entre emails consecutivos. Não diga "conforme esclarecemos anteriormente" a menos que esteja respondendo a uma thread do mesmo remetente
- **"Pode reembolsar" em MED ≠ estorno voluntário** — não confundir. Em MED, o lojista está autorizando a devolução dentro do processo de contestação, não pedindo um reembolso ativo da PixGo
- **Nunca pedir comprovantes ao lojista** — PixGo é imparcial na relação comercial
- **Nunca inventar justificativas sobre como MEDs são abertos** — NÃO diga que o MED pode ter sido aberto "pelo banco do cliente" ou "por terceiros sem o cliente saber". Isso não procede e o usuário corrige na hora. O MED é um recurso solicitado pelo próprio cliente junto ao banco dele. Ficar estritamente nos fatos que o lojista apresentou, sem especular.
- Cada email é de um USUÁRIO DIFERENTE — não assumir continuidade de conversa

### Tópicos sobre Subcontas e Afiliados
- **Não existe subconta nativa** na PixGO
- Sistema de **Team Management (Equipe)**: adicionar vendedores que geram cobrança em seu nome, valores caem na conta principal
- **Programa de Afiliados**: 10% do lucro da PixGO, pago em DEPIX na wallet Liquid
- Afiliado recebe em DEPIX (crypto sim — stablecoin BRL na Liquid Network)
- Para converter: BrSwap.me (DEPIX → USDT) ou CryPix.me (DEPIX → PIX)
- Não há payout automático em USDT/BTC — precisa converter após receber

## API Endpoints
- URL Base: `https://pixgo.org/api/v1`
- Auth: Header `X-API-Key`
- Rate Limit: 50.000 requests/24h por chave

### Criar Pagamento
`POST /api/v1/payment/create`
Campos: amount, description, customer_name, customer_cpf, customer_email, customer_phone, customer_address, external_id, webhook_url

### Verificar Status
`GET /api/v1/payment/{id}/status`

### Obter Detalhes
`GET /api/v1/payment/{id}`

## Informações Institucionais
- PixGo NÃO é instituição financeira — é interface tecnológica
- Processamento bancário, compliance (KYC/AML) e estornos feitos por Xend e Transfero
- Conversão BRL → DEPIX é da Depix.info
- Liquidação D+1 corrido (inclui fins de semana e feriados)
- Custódia temporária por segurança anti-fraude
- Zero tolerância: IPTV, streaming ilegal, pedofilia, drogas, fraudes → suspensão sumária
- Impostos são responsabilidade 100% do usuário
